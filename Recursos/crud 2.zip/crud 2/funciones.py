def listarEnvasado(listaEntidades):
    print("\ + {EntidadAUsar} + s: \n")
    contador = 1
    for entidad in listaEntidades:
        datos = "{0}. Código: {1} | Fecha: {2}  lote_codigo {3}  Muestreo {4}"
        print(datos.format(contador, entidad[0], entidad[1], entidad[2],entidad[3]))
        contador = contador + 1
    print(" ")
    
    
def listarMuestreo(listaEntidades):
    print("\ + {Muestreo} + s: \n")
    contador = 1
    for entidad in listaEntidades:
        datos = "{0}. Código: {1} | Fecha: {2}  lote_codigo {3}  Muestreo {4}"
        print(datos.format(contador, entidad[0], entidad[1], entidad[2],entidad[3]))
        contador = contador + 1
    print(" ")
    
def pedirDatosEnvasado():


    codigo = int(input("Ingrese código: "))
       
    
    codigoLoteMuestreo = int(input("Ingrese el codigo del muestreo"))

    codigoLote= int(input("Ingrese codigo lote: "))
    
    fecha = input("Ingrese fecha: ")
    
   

    envasado = (codigo,fecha, codigoLote,codigoLoteMuestreo)
    
    
    return envasado

def pedirDatosActualizacion(listaEnvases,entidadAUsar):
    listarEnvasado(listaEnvases,entidadAUsar)

    codigoEditar = input("Ingrese el código de la entidad a editar: ")
    for cur in listaEnvases:
        if cur[0] == codigoEditar:
            existeCodigo = True
            break

 
    fechaEnvase = input("Ingrese la fecha a modificar: ")

      
    loteCodigo = input("Ingrese lote codigo a modificar: ")
        
        
    codigoMuestreo = input ("Ingrese el codigo del muestreo para modificar")
 

    curso = (codigoEditar, fechaEnvase,loteCodigo, codigoMuestreo)
   
    return curso


def pedirDatosEliminacion(listaEnvases):
    listarEnvasado(listaEnvases)
    existeCodigo = False
    codigoEliminar = int(input("Ingrese el código del envase a eliminar: "))
    for envase in listaEnvases:
        if envase[0] == codigoEliminar:
            existeCodigo = True
            break

    if not existeCodigo:
        codigoEliminar = ""

    return codigoEliminar