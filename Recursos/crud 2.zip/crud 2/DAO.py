import mysql.connector
from mysql.connector import Error
import datetime


#Se hace la conexion a la base de datos
class DAO():
   
        def  __init__(self):

            self.connection = mysql.connector.connect(
                     host='localhost',
                     port=3306,
                     user='root',
                     password='1234',
                     db='proyecto_bases'
                    )
                
               
            self.cursor = self.connection.cursor()

            print("Conexion establecida exitosamente")
                
        def listar(self,entidadAUsar):
            if self.connection.is_connected():
                try:
                    cursor = self.connection.cursor()
                    cursor.execute("SELECT * FROM " + entidadAUsar)
                    resultados = cursor.fetchall()
                    return resultados
                except Error as ex:
                    print("Error al intentar la conexión: {0}".format(ex))
                    
                    
        def registrar(self,envasado):
            if self.connection.is_connected():
                cursor = self.connection.cursor()
                sql = "INSERT INTO envasado (codigo, fecha, Lote_codigo,Muestreo_codigo) VALUES ({0}, '{1}', {2}, {3})"
                self.cursor.execute(sql.format(envasado[0], envasado[1],envasado[2],envasado[3]))
                self.connection.commit()
                print("¡Curso registrado!\n")
              

        def actualizar(self, envasado):
            if self.connection.is_connected():
                try:
                    cursor = self.connection.cursor()
                    sql = "UPDATE envasado SET codigo = {0}, fecha = '{1}',lote_codigo = {2},muestreo_codigo ={3} WHERE codigo = '{2}'"
                    cursor.execute(sql.format(envasado[0], envasado[1], envasado[2],envasado[3]))
                    self.connection.commit()
                    print("¡Curso actualizado!\n")
                except Error as ex:
                    print("Error al intentar la conexión: {0}".format(ex))

        def eliminar(self, codigoCursoEliminar):
            if self.connection.is_connected():
                try:
                    cursor = self.connection.cursor()
                    sql = "DELETE FROM envasado WHERE codigo = {0}"
                    cursor.execute(sql.format(codigoCursoEliminar))
                    self.connection.commit()
                    print("¡Curso eliminado!\n")
                except Error as ex:
                    print("Error al intentar la conexión: {0}".format(ex))
                        
            